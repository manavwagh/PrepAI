"use client";

import { motion, AnimatePresence } from "framer-motion";
import { CreditCard, ShieldCheck, X, CheckCircle2, Loader2 } from "lucide-react";
import { useState } from "react";

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function CheckoutModal({ isOpen, onClose, onSuccess }: CheckoutModalProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handlePayment = () => {
    setIsProcessing(true);
    // Simulate payment delay
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      // Success animation delay
      setTimeout(() => {
        onSuccess();
        onClose();
      }, 2000);
    }, 2500);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-md overflow-hidden rounded-3xl border border-white/10 bg-zinc-900 p-8 shadow-2xl"
          >
            {isSuccess ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center justify-center py-12 text-center"
              >
                <div className="mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-green-500/20 text-green-500">
                  <CheckCircle2 className="h-12 w-12" />
                </div>
                <h2 className="text-3xl font-bold text-white uppercase tracking-tight">Payment Successful!</h2>
                <p className="mt-2 text-zinc-400">Welcome to PrepAI Pro. Unlocking your features now...</p>
              </motion.div>
            ) : (
              <>
                <button 
                  onClick={onClose}
                  className="absolute top-6 right-6 text-zinc-500 hover:text-white transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>

                <div className="mb-8">
                  <h2 className="text-2xl font-bold text-white">Upgrade to Pro</h2>
                  <p className="text-sm text-zinc-500 mt-1">Join 2,000+ candidates landing top roles.</p>
                </div>

                <div className="space-y-6">
                  {/* Pricing Info */}
                  <div className="flex items-center justify-between rounded-xl bg-primary/10 border border-primary/20 p-4">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-wider text-primary">Annual Plan</p>
                      <p className="text-sm text-white">Full Platform Access</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-white">$49</p>
                      <p className="text-[10px] text-zinc-500">/year</p>
                    </div>
                  </div>

                  {/* Card Details (Mock) */}
                  <div className="space-y-4">
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">Card Number</label>
                      <div className="mt-1 flex items-center gap-3 rounded-lg border border-white/10 bg-white/5 px-4 py-3">
                        <CreditCard className="h-4 w-4 text-zinc-600" />
                        <input 
                          type="text" 
                          placeholder="4242 4242 4242 4242" 
                          className="flex-1 bg-transparent text-sm outline-none placeholder:text-zinc-700" 
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">Expiry</label>
                        <input 
                          type="text" 
                          placeholder="MM / YY" 
                          className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none placeholder:text-zinc-700" 
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">CVC</label>
                        <input 
                          type="text" 
                          placeholder="•••" 
                          className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none placeholder:text-zinc-700" 
                        />
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={handlePayment}
                    disabled={isProcessing}
                    className="w-full flex items-center justify-center gap-2 rounded-xl bg-primary py-4 font-bold text-white hover:bg-primary/90 transition-all disabled:opacity-50"
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="h-5 w-5 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="h-5 w-5" />
                        Pay $49.00
                      </>
                    )}
                  </button>

                  <p className="text-center text-[10px] text-zinc-600">
                    Secure checkout powered by Stripe. No data is stored.
                  </p>
                </div>
              </>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
